# Pothole_Segmentation_YOLOv8 > 2023-10-20 10:09pm
https://universe.roboflow.com/farzad/pothole_segmentation_yolov8

Provided by a Roboflow user
License: CC BY 4.0

